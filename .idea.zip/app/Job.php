<?php

namespace App;
use User;

use Illuminate\Database\Eloquent\Model;

class Job extends Model
{
    public function getnames(){
      return 123;
    }
}
